package com.java.manager;

import java.sql.Date;

public class Subscriptions {

	private int subscriptionId;
	private int planId;
	private String insuranceId;
	private String insuranceName;
	private double premiumAmount;
	private double coverageAmount;
	private String payMode;
	private String email;
	private Date registrationDate;
	private double initialAmount;
	private String status;
	private String uhId;
	private Date endDate;
	
	
	public int getSubscriptionId() {
		return subscriptionId;
	}
	public void setSubscriptionId(int subscriptionId) {
		this.subscriptionId = subscriptionId;
	}
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public String getInsuranceId() {
		return insuranceId;
	}
	public void setInsuranceId(String insuranceId) {
		this.insuranceId = insuranceId;
	}
	public String getInsuranceName() {
		return insuranceName;
	}
	public void setInsuranceName(String insuranceName) {
		this.insuranceName = insuranceName;
	}
	public double getPremiumAmount() {
		return premiumAmount;
	}
	public void setPremiumAmount(double premiumAmount) {
		this.premiumAmount = premiumAmount;
	}
	public double getCoverageAmount() {
		return coverageAmount;
	}
	public void setCoverageAmount(double coverageAmount) {
		this.coverageAmount = coverageAmount;
	}
	public String getPayMode() {
		return payMode;
	}
	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}
	public double getInitialAmount() {
		return initialAmount;
	}
	public void setInitialAmount(double initialAmount) {
		this.initialAmount = initialAmount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getUhId() {
		return uhId;
	}
	public void setUhId(String uhId) {
		this.uhId = uhId;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	@Override
	public String toString() {
		return "Subscriptions [subscriptionId=" + subscriptionId + ", planId=" + planId + ", insuranceId=" + insuranceId
				+ ", insuranceName=" + insuranceName + ", premiumAmount=" + premiumAmount + ", coverageAmount="
				+ coverageAmount + ", payMode=" + payMode + ", email=" + email + ", registrationDate="
				+ registrationDate + ", initialAmount=" + initialAmount + ", status=" + status + ", uhId=" + uhId
				+ ", endDate=" + endDate + "]";
	}
	
	
	
	
	
}
