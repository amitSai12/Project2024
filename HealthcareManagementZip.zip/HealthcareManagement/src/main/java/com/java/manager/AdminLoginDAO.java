package com.java.manager;

public interface AdminLoginDAO {
	String adminSignIn(AdminLogin admin);
	public String loginDao(AdminLogin adminauth);
}
