package com.java.manager;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ValueChangeEvent;

import org.apache.http.ParseException;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

public class PatientDAOImpl implements PatientDAO{

	SessionFactory sf;
	Session session;
	
	
	// clear 
	
	public void clear(Patient_Enrollment patient, JsfPaginationBean pageDao) {
		patient.setUhId("");
		patient.setFirstName("");
		patient.setUserName("");
		patient.setStatus("");
		resetSorting();
		pageDao.setFirstRow(0);
	}
	
	//reset the sorting of the table
	
	public void resetSorting() {
		orderByUhId = "test";
		orderByfirstName = "test";
		orderByLastName = "test";
		orderByGender = "test";
		orderByDob = "test";
		orderByUsername = "test";
		orderByEmail = "test";
		orderByStatus = "test";
	}
	
	
	// sorting identifiers used in methods
	
	static String orderByUhId = "test";
	static String orderByfirstName = "test";
	static String orderByLastName = "test";	
	static String orderByGender = "test";
	static String orderByDob = "test";
	static String orderByUsername = "test";
	static String orderByEmail = "test";
	static String orderByStatus = "test";
	
	

	


	public String getOrderByUhId() {
		return orderByUhId;
	}

	public void setOrderByUhId(String orderByUhId) {
		this.orderByUhId = orderByUhId;
	}

	public String sortByPatientId(Patient_Enrollment patient) {
	    Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
	    patient.setUhId("");
		patient.setFirstName("");
		patient.setUserName("");
		patient.setStatus("");
	    if (orderByUhId.equals("desc")) {
	        // Ascending order, switch to descending
	    	orderByUhId = "asc";
	    	
	    	orderByfirstName = "test";
	    	orderByLastName = "test";
	    	orderByGender = "test";
	    	orderByDob = "test";
	    	orderByUsername = "test";
	    	orderByEmail = "test";
	    	orderByStatus = "test";
	    } else if (orderByUhId.equals("asc")) {
	        // Descending order, switch to ascending
	    	orderByUhId = "desc";
	    	
	    	orderByfirstName = "test";
	    	orderByLastName = "test";
	    	orderByGender = "test";
	    	orderByDob = "test";
	    	orderByUsername = "test";
	    	orderByEmail = "test";
	    	orderByStatus = "test";
	    	
		}else {
			orderByUhId = "asc";
		}
	    return "ShowPatientAppointment.jsp?faces-redirect=true";
	}
	
	public String sortByFirstName() {
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		if (orderByfirstName.equals("desc")) {
			// Ascending order, switch to descending
			orderByfirstName = "asc";
			
			orderByUhId = "test";
	    	orderByLastName = "test";
	    	orderByGender = "test";
	    	orderByDob = "test";
	    	orderByUsername = "test";
	    	orderByEmail = "test";
	    	orderByStatus = "test";
		} else if (orderByfirstName.equals("asc")) {
			// Descending order, switch to ascending
			orderByfirstName = "desc";
			
			orderByUhId = "test";
	    	orderByLastName = "test";
	    	orderByGender = "test";
	    	orderByDob = "test";
	    	orderByUsername = "test";
	    	orderByEmail = "test";
	    	orderByStatus = "test";
		
		}else {
			orderByfirstName="asc";
		}
		return "ShowPatientAppointment.jsp?faces-redirect=true";
	}
	
	public String sortByLastName() {
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		if (orderByLastName.equals("desc")) {
			// Ascending order, switch to descending
			orderByLastName = "asc";
			
			orderByUhId = "test";
	    	orderByfirstName = "test";
	    	orderByGender = "test";
	    	orderByDob = "test";
	    	orderByUsername = "test";
	    	orderByEmail = "test";
	    	orderByStatus = "test";
		} else if (orderByLastName.equals("asc")) {
			// Descending order, switch to ascending
			orderByLastName = "desc";
		
			orderByUhId = "test";
	    	orderByfirstName = "test";
	    	orderByGender = "test";
	    	orderByDob = "test";
	    	orderByUsername = "test";
	    	orderByEmail = "test";
	    	orderByStatus = "test";
		}else {
			orderByLastName= "asc";
		}
		
		
		return "ShowPatientAppointment.jsp?faces-redirect=true";
	}
	
	public String sortByGender() {
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		if (orderByGender.equals("desc")) {
			// Ascending order, switch to descending
			orderByGender = "asc";
			
			orderByUhId = "test";
	    	orderByfirstName = "test";
	    	orderByLastName = "test";
	    	orderByDob = "test";
	    	orderByUsername = "test";
	    	orderByEmail = "test";
	    	orderByStatus = "test";
		} else if (orderByGender.equals("asc")) {
			// Descending order, switch to ascending
			orderByGender = "desc";
			
			orderByUhId = "test";
	    	orderByfirstName = "test";
	    	orderByLastName = "test";
	    	orderByDob = "test";
	    	orderByUsername = "test";
	    	orderByEmail = "test";
	    
		}else {
			orderByGender="asc";
		}
		return "ShowPatientAppointment.jsp?faces-redirect=true";
	}
	
	public String sortByDob() {
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		if (orderByDob.equals("asc")) {
			// Ascending order, switch to descending
			orderByDob = "desc";
			
			orderByUhId = "test";
	    	orderByfirstName = "test";
	    	orderByLastName = "test";
	    	orderByGender = "test";
	    	orderByUsername = "test";
	    	orderByEmail = "test";
	    	orderByStatus = "test";
		} else if (orderByDob.equals("desc")) {
			// Descending order, switch to ascending
			orderByDob = "asc";
			
			orderByUhId = "test";
	    	orderByfirstName = "test";
	    	orderByLastName = "test";
	    	orderByGender = "test";
	    	orderByUsername = "test";
	    	orderByEmail = "test";
	    	orderByStatus = "test";
		
		}else {
			orderByDob="asc";
		}
		return "ShowPatientAppointment.jsp?faces-redirect=true";
	}
	public String sortByUsername() {
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		if (orderByUsername.equals("asc")) {
			orderByUsername = "desc";
			
						orderByUhId = "test";
				    	orderByfirstName = "test";
				    	orderByLastName = "test";
				    	orderByGender = "test";
				    	orderByDob ="test";
				    	orderByEmail = "test";
				    	orderByStatus = "test";
		} else if (orderByUsername.equals("desc")) {
			// Descending order, switch to ascending
			orderByUsername = "asc";
			

			orderByUhId = "test";
	    	orderByfirstName = "test";
	    	orderByLastName = "test";
	    	orderByGender = "test";
	    	orderByDob ="test";
	    	orderByEmail = "test";
	    	orderByStatus = "test";
		 
		}else {
			orderByUsername="asc";
		}
		return "ShowPatientAppointment.jsp?faces-redirect=true";
	}
	public String sortByEmail() {
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		if (orderByEmail.equals("asc")) {
			// Ascending order, switch to descending
			orderByEmail = "desc";
			
			orderByUhId = "test";
	    	orderByfirstName = "test";
	    	orderByLastName = "test";
	    	
	    	orderByGender = "test";
	    	orderByDob ="test";
	    	orderByUsername="test";
	    	orderByStatus = "test";
		} else if (orderByEmail.equals("desc")) {
			// Descending order, switch to ascending
			orderByEmail = "asc";
			
			orderByUhId = "test";
	    	orderByfirstName = "test";
	    	orderByLastName = "test";
	    	
	    	orderByGender = "test";
	    	orderByDob ="test";
	    	orderByUsername="test";
	    	orderByStatus = "test";
		}else {
			orderByEmail="asc";
		}
		return "ShowPatientAppointment.jsp?faces-redirect=true";
	}
	
	public String sortByStatus() {
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		if (orderByStatus.equals("asc")) {
			// Ascending order, switch to descending
			orderByStatus = "desc";
			
			orderByUhId = "test";
	    	orderByfirstName = "test";
	    	orderByLastName = "test";
	    	
	    	orderByGender = "test";
	    	orderByDob ="test";
	    	orderByUsername="test";
	    	orderByEmail="test";
		} else if (orderByStatus.equals("desc")) {
			// Descending order, switch to ascending
			orderByStatus = "asc";
			

			orderByUhId = "test";
	    	orderByfirstName = "test";
	    	orderByLastName = "test";
	    	
	    	orderByGender = "test";
	    	orderByDob ="test";
	    	orderByUsername="test";
	    	orderByEmail="test";
		}else {
			orderByStatus="asc";
		}
		return "ShowPatientAppointment.jsp?faces-redirect=true";
	}
	
	
	@Override
	public List<Patient_Enrollment> showPatient() {
		
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr = session.createCriteria(Patient_Enrollment.class);
		return cr.list();
	}
	
//	@Override
//	public List<Patient_Enrollment> searchPatient(String uhId, String firstName, String userName, String status) {
//		
//		 sf = SessionHelper.getConnection();
//         session = sf.openSession();
//         Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
//        
//        Criteria criteria = session.createCriteria(Patient_Enrollment.class);
//       
//        if (uhId.length() > 0) {
//        	
//        	System.out.println("Hi");
//        	
//        	criteria.add(Restrictions.ilike("uhId", "%" + uhId + "%")); 
//            sessionMap.put("uhId",uhId );
//        }
//        
//        if (firstName.length() > 0) {
//        	
//        	System.out.println("Hello");
//        	
//        	criteria.add(Restrictions.ilike("firstName", "%" + firstName + "%")); 	
//            sessionMap.put("firstName",firstName);
//        }
//        
//        if (userName.length() > 0) {
//        	
//        	System.out.println("Test");
//        	
//        	criteria.add(Restrictions.ilike("userName", "%" + userName + "%")); 
//        	sessionMap.put("userName",userName);
//        }
//        
//        if (status != null && !status.isEmpty()) {
//        	criteria.add(Restrictions.eq("status", status.toUpperCase()));
//	    }
//    
//  
//        if(orderByUhId.equals("asc")) {
//        	criteria.addOrder(Order.asc("uhId"));
//        }else if(orderByUhId.equals("desc")) {
//        	criteria.addOrder(Order.desc("uhId"));
//        }
//        
//        if(orderByfirstName.equals("asc")) {
//        	criteria.addOrder(Order.asc("firstName"));
//        }else if(orderByfirstName.equals("desc")) {
//        	criteria.addOrder(Order.desc("firstName"));
//        }
//        
//        if(orderByLastName.equals("asc")) {
//        	criteria.addOrder(Order.asc("lastName"));
//        }else if(orderByLastName.equals("desc")) {
//        	criteria.addOrder(Order.desc("lastName"));
//        }
//        if(orderByGender.equals("asc")) {
//        	criteria.addOrder(Order.asc("gender"));
//        }else if(orderByGender.equals("desc")) {
//        	criteria.addOrder(Order.desc("gender"));
//        }
//        if(orderByDob.equals("asc")) {
//        	criteria.addOrder(Order.asc("dob"));
//        }else if(orderByDob.equals("desc")) {
//        	criteria.addOrder(Order.desc("dob"));
//        }
//        if(orderByUsername.equals("asc")) {
//        	criteria.addOrder(Order.asc("userName"));
//        }else if(orderByUsername.equals("desc")) {
//        	criteria.addOrder(Order.desc("userName"));
//        }
//        
//        if(orderByEmail.equals("asc")) {
//        	criteria.addOrder(Order.asc("email"));
//        }else if(orderByEmail.equals("desc")) {
//        	criteria.addOrder(Order.desc("email"));
//        }
//        
//        if(orderByStatus.equals("asc")) {
//        	criteria.addOrder(Order.asc("status"));
//        }else if(orderByStatus.equals("desc")) {
//        	criteria.addOrder(Order.desc("status"));
//        }
//        
//        sessionMap.clear();
//        List<Patient_Enrollment> patientList = criteria.list();
//        return patientList;
//
//	}
	
	// to get the UhId -----------------------------------------------------------------------------------------------
	
	public String patientId(String uhId) {	
		// get the sessionMap from the current faces context
		Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		
		System.out.println("SearchBeforeUhId: "+uhId);
		
		Criteria cr = session.createCriteria(Patient_Enrollment.class);
		cr.add(Restrictions.eq("uhId", uhId));
		
		System.out.println("SearchAfterUhId: "+uhId);
		
		List<Patient_Enrollment> patientList = cr.list();
		
		System.out.println("PatientList: "+patientList);
		
		//returning the patientList with according to the fetched uhId 
		//this is implemented for the show details
		sessionMap.put("uhId", uhId);
		sessionMap.put("patientList", patientList);
		
		return "ShowPatientDetails.jsp?faces-redirect=true";
		
	}
	
	//to get the PatientList details of the uhId provided to confirm or cancel-----------------------------------------------------------------------------
	
	public Patient_Enrollment searchPatientList(String uhId) throws ParseException{
		
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		
		Criteria criteria = session.createCriteria(Patient_Enrollment.class);
		criteria.add(Restrictions.eq("uhId", uhId));
		
		//as uhId is unique, this line is expected to execute the query and get a unique result
		Patient_Enrollment patientDetail =  (Patient_Enrollment) criteria.uniqueResult();
		sessionMap.put("patientDetail", patientDetail);
		System.out.println(patientDetail);
		return patientDetail;
	}
	
	//--------------------------------------------------------------------------------------
	public int countRows(String uhId, String firstName, String userName, String status) {
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		try {
			session.beginTransaction();
			Criteria criteria = session.createCriteria(Patient_Enrollment.class);
			if (criteria != null) {
				
				 if (uhId!=null && uhId.length() > 0) {
				       	
				       	System.out.println("Hi");
				       	
				       	criteria.add(Restrictions.ilike("uhId", "%" + uhId + "%")); 
				           sessionMap.put("uhId",uhId );
				       }
				       
				       if (firstName!=null && firstName.length() > 0) {
				       	
				       	System.out.println("Hello");
				       	
				       	criteria.add(Restrictions.ilike("firstName", "%" + firstName + "%"));
				           sessionMap.put("firstName",firstName);
				       }
				       
				       if (userName!=null && userName.length() > 0) {
				       	
				       	System.out.println("Test");
				       	
				       	criteria.add(Restrictions.ilike("userName", "%" + userName + "%")); 
				       	sessionMap.put("userName",userName);
				       }
				       
				       if (status != null && !status.isEmpty()) {
				       	criteria.add(Restrictions.eq("status", status.toUpperCase()));
					    }
				   
				       if(orderByfirstName.equals("desc")) {
				       	criteria.addOrder(Order.asc("firstName"));
				       }else if(orderByfirstName.equals("asc")) {
				       	criteria.addOrder(Order.desc("firstName"));
				       }
				       
				       if(orderByUhId.equals("desc")) {
				       	criteria.addOrder(Order.asc("uhId"));
				       }else if(orderByUhId.equals("asc")) {
				       	criteria.addOrder(Order.desc("uhId"));
				       }
				       
				       if(orderByLastName.equals("asc")) {
				       	criteria.addOrder(Order.asc("lastName"));
				       }else if(orderByLastName.equals("desc")) {
				       	criteria.addOrder(Order.desc("lastName"));
				       }
				       
				       if(orderByGender.equals("asc")) {
				        	criteria.addOrder(Order.asc("gender"));
				        }else if(orderByGender.equals("desc")) {
				        	criteria.addOrder(Order.desc("gender"));
				        }
				        if(orderByDob.equals("asc")) {
				        	criteria.addOrder(Order.asc("dob"));
				        }else if(orderByDob.equals("desc")) {
				        	criteria.addOrder(Order.desc("dob"));
				        }
				        if(orderByUsername.equals("asc")) {
				        	criteria.addOrder(Order.asc("userName"));
				        }else if(orderByUsername.equals("desc")) {
				        	criteria.addOrder(Order.desc("userName"));
				        }
				        
				        if(orderByEmail.equals("asc")) {
				        	criteria.addOrder(Order.asc("email"));
				        }else if(orderByEmail.equals("desc")) {
				        	criteria.addOrder(Order.desc("email"));
				        }
				        
				        if(orderByStatus.equals("asc")) {
				        	criteria.addOrder(Order.asc("status"));
				        }else if(orderByStatus.equals("desc")) {
				        	criteria.addOrder(Order.desc("status"));
				        }
				
				        System.out.println("SizeList:"+criteria.list().size());
				return criteria.list().size();
				       
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	//to make the status ACTIVE
	
	public String confirmAppointment(String uhId) throws ParseException {
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		FacesContext context = FacesContext.getCurrentInstance();
		System.out.println("APPOINTMENTID "+uhId);
		Patient_Enrollment patientFound = searchPatientList(uhId);
		patientFound.setStatus("ACTIVE");
		System.out.println("APPOINTMENFOUND "+patientFound);
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Transaction trans = session.beginTransaction();
		session.update(patientFound);
		trans.commit();
		
		System.out.println(patientFound);
		context.addMessage("manageMsg", new FacesMessage("Plan Confirmed..."));
		sessionMap.put("manageMsg", "confirmed");
		return "Confirm.jsp?faces-redirect=true";
	}
	
	//to make the status PENDING
	
	public String cancelAppointment(String uhId) throws ParseException {
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		FacesContext context = FacesContext.getCurrentInstance();
		Patient_Enrollment patientFound = searchPatientList(uhId);
		patientFound.setStatus("PENDING");
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Transaction trans = session.beginTransaction();
		session.update(patientFound);
		trans.commit();
		
		context.addMessage("manageMsg", new FacesMessage("Plan Canceled..."));
		sessionMap.put("manageMsg", "canceled");
		return "ConfirmInactive.jsp?faces-redirect=true";
	}
	
	//main implementation method 
	
	
	@Override
	public List<Patient_Enrollment> searchPatient(int firstRow, int rowCount, String uhId, String firstName, String userName, String status) {
		sf = SessionHelper.getConnection();
        session = sf.openSession();
        Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
       Criteria criteria = session.createCriteria(Patient_Enrollment.class);
      
      if(firstName.length()>0) {
    	  firstRow = 0;
      }
      if(uhId.length()>0) {
    	  firstRow = 0;
      }
      if(userName!=null && userName.length()>0) {
    	  firstRow = 0;
      }
      
       if (uhId!=null && uhId.length() > 0) {
       	
       	System.out.println("Hi");
       	criteria.add(Restrictions.ilike("uhId", "%" + uhId + "%")); 
           sessionMap.put("uhId",uhId );
       }
       
       if (firstName!=null && firstName.length() > 0) {
       	
       	System.out.println("Hello");
       	
       	criteria.add(Restrictions.ilike("firstName", "%" + firstName + "%")); 	
           sessionMap.put("firstName",firstName);
       }
       
       if (userName!=null && userName.length() > 0) {
       	
       	System.out.println("Test");
       	
       	criteria.add(Restrictions.ilike("userName", "%" + userName + "%")); 
       	sessionMap.put("userName",userName);
       }
       
       if (status != null && !status.isEmpty()) {
       	criteria.add(Restrictions.eq("status", status.toUpperCase()));
	    }
   
       
       if(orderByfirstName.equals("desc")) {
	       	criteria.addOrder(Order.asc("firstName"));
	       }else if(orderByfirstName.equals("asc")) {
	       	criteria.addOrder(Order.desc("firstName"));
	       }
	       
	       if(orderByUhId.equals("desc")) {
	       	criteria.addOrder(Order.asc("uhId"));
	       }else if(orderByUhId.equals("asc")) {
	       	criteria.addOrder(Order.desc("uhId"));
	       }
	       
	       if(orderByLastName.equals("desc")) {
	       	criteria.addOrder(Order.asc("lastName"));
	       }else if(orderByLastName.equals("asc")) {
	       	criteria.addOrder(Order.desc("lastName"));
	       }
	       
	       if(orderByGender.equals("desc")) {
	        	criteria.addOrder(Order.asc("gender"));
	        }else if(orderByGender.equals("asc")) {
	        	criteria.addOrder(Order.desc("gender"));
	        }
	        if(orderByDob.equals("desc")) {
	        	criteria.addOrder(Order.asc("dob"));
	        }else if(orderByDob.equals("asc")) {
	        	criteria.addOrder(Order.desc("dob"));
	        }
	        if(orderByUsername.equals("desc")) {
	        	criteria.addOrder(Order.asc("userName"));
	        }else if(orderByUsername.equals("asc")) {
	        	criteria.addOrder(Order.desc("userName"));
	        }
	        
	        if(orderByEmail.equals("desc")) {
	        	criteria.addOrder(Order.asc("email"));
	        }else if(orderByEmail.equals("asc")) {
	        	criteria.addOrder(Order.desc("email"));
	        }
	        
	        if(orderByStatus.equals("desc")) {
	        	criteria.addOrder(Order.asc("status"));
	        }else if(orderByStatus.equals("asc")) {
	        	criteria.addOrder(Order.desc("status"));
	        }
	        
       // sessionMap.clear();
	   
       sessionMap.remove("error");
       criteria.setFirstResult(firstRow);
       criteria.setMaxResults(rowCount);
       System.out.println("First Row: "+firstRow);
       System.out.println("Row Count: "+rowCount);
       List<Patient_Enrollment> patientList = criteria.list();
       System.out.println("PatientList: "+patientList);
       return patientList;
	}
	
//	public List<Patient_Enrollment> getPatientAppointmentList(int firstRow, int rowsPerPage) {
//		System.out.println("Rows per page"+ rowsPerPage);
//		SessionFactory sf = SessionHelper.getConnection();
//		Session session = sf.openSession();
//		List<Patient_Enrollment> ptList = null;
//			session.beginTransaction();
//			Criteria criteria = session.createCriteria(Patient_Enrollment.class);
//			criteria.setFirstResult(firstRow);
//			criteria.setMaxResults(rowsPerPage);
//		return criteria.list();
//	}
}
