package com.java.manager;

import java.util.regex.Pattern;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.naming.NamingException;

public class Controller {
    private Patient_Enrollment patient;
    private PatientDAOImpl pImpl;
    private JsfPaginationBean pageDao;	

	public JsfPaginationBean getPageDao() {
		return pageDao;
	}

	public void setPageDao(JsfPaginationBean pageDao) {
		this.pageDao = pageDao;
	}

	public Patient_Enrollment getPatient() {
		return patient;
	}

	public void setPatient(Patient_Enrollment patient) {
		this.patient = patient;
	}

	public PatientDAOImpl getpImpl() {
		return pImpl;
	}

	public void setpImpl(PatientDAOImpl pImpl) {
		this.pImpl = pImpl;
	}

	public List<Patient_Enrollment> searchMember(String uhId, String firstName, String userName, String status) throws ClassNotFoundException, NamingException, ParseException {
		System.out.println("Inside the Controller Class");
		if(updateValid(uhId,firstName,userName,status)) {
			System.out.println("Inside the Controller Class Method of Update valid");
			return pageDao.getMemberSearchList(uhId, firstName, userName, status);
		}
		return null;
	}
	
	public boolean updateValid(String uhId, String firstName, String userName, String status){
		
		FacesContext context = FacesContext.getCurrentInstance();
		/*
		 * SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd"); String apDate =
		 * sdf.format(appointment.getAppointmentDate());
		 * System.out.println("date Test : "+apDate);
		 * System.out.println("date Test 1 : "+appointment.getAppointmentDate());
		 */
		boolean flag=true;
		
		/* String validName = "^.{1,10}$"; */
		
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		
		String validName = "^[a-zA-Z]+$";
//		String validId = "^[a-zA-Z0-9]+$";
		String validId = "^[a-zA-Z0-9]+$";
		String validUser = "^\\S+$";


		/* String validSpace = "/^\\S*$/"; */

		if (uhId.length()<=0  && firstName.length()<=0 && userName.length()<=0 && status.length()<=0) {
	        sessionMap.put("error", "You must choose at least one field to search !!");
	        context.addMessage("form:error", new FacesMessage(FacesMessage.SEVERITY_ERROR, "You must choose at least one search attribute", null));
	        flag = false;
	    }
		
		/*
		 *if(uhId.matches(validSpace)){ sessionMap.put("error2",
		 * "UHID must not contain any spaces");
		 * context.addMessage("form:error", new
		 * FacesMessage(FacesMessage.SEVERITY_ERROR,
		 * "You must choose at least one search attribute", null)); flag = false; }
		 *if(firstName.matches(validSpace)){ sessionMap.put("error3",
		 *"FirstName must not contain any spaces"); context.addMessage("form:error",
		 *new FacesMessage(FacesMessage.SEVERITY_ERROR,
		 *"You must choose at least one search attribute", null)); flag = false; }
		 *if(userName.matches(validSpace)){ sessionMap.put("error4",
		 *"UserName must not contain any spaces"); context.addMessage("form:error", new
		 *FacesMessage(FacesMessage.SEVERITY_ERROR,
		 *"You must choose at least one search attribute", null)); flag = false; }
		 */
		
		if (firstName.length()!=0 && !firstName.matches(validName)) {
	        sessionMap.put("error", "First Name shouldn't contain any digits or spaces or special charachters !");
	        context.addMessage("form:error1", new FacesMessage(FacesMessage.SEVERITY_ERROR, "First Name shouldn't contain any digits", null));
	        flag = false;
		}
		if (uhId.length()!=0 && !uhId.matches(validId)) {
			sessionMap.put("error", "PatientId shouldn't contain any spaces or special charachters and should start with IN followed by numbers !");
			context.addMessage("form:error1", new FacesMessage(FacesMessage.SEVERITY_ERROR, "First Name shouldn't contain any digits", null));
			flag = false;
		}
		if (userName.length()!=0 && !userName.matches(validUser)) {
			sessionMap.put("error", "Username shouldn't contain any spaces !");
			context.addMessage("form:error1", new FacesMessage(FacesMessage.SEVERITY_ERROR, "First Name shouldn't contain any digits", null));
			flag = false;
		}

		
		return flag;
	}
    
}