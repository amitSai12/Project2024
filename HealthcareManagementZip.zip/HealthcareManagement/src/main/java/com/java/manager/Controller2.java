package com.java.manager;

import java.util.regex.Pattern;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.naming.NamingException;

public class Controller2 {
    private Subscriptions sub;
    private SubscriptionImpl subImpl;
    private JsfPaginationBean2 pageDao2;	

//	

	public Subscriptions getSub() {
		return sub;
	}

	public void setSub(Subscriptions sub) {
		this.sub = sub;
	}

	public SubscriptionImpl getSubImpl() {
		return subImpl;
	}

	public void setSubImpl(SubscriptionImpl subImpl) {
		this.subImpl = subImpl;
	}

	public JsfPaginationBean2 getPageDao2() {
		return pageDao2;
	}

	public void setPageDao2(JsfPaginationBean2 pageDao2) {
		this.pageDao2 = pageDao2;
	}

	public List<Subscriptions> searchMember(String insuranceId, String uhId) throws ClassNotFoundException, NamingException, ParseException {
		System.out.println("Insurance Id Update Valid: "+insuranceId);
		if(updateValid2(insuranceId)) {
			return pageDao2.getInsSearchList(insuranceId,uhId);
		}
		return null;
	}
	
	public boolean updateValid2(String insuranceId){
		
		FacesContext context = FacesContext.getCurrentInstance();
		/*
		 * SimpleDateFormat sdf = new SimpleDateFormat("yyyy-mm-dd"); String apDate =
		 * sdf.format(appointment.getAppointmentDate());
		 * System.out.println("date Test : "+apDate);
		 * System.out.println("date Test 1 : "+appointment.getAppointmentDate());
		 */
		boolean flag=true;
		
		/* String validName = "^.{1,10}$"; */
		
		Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		
		
//		String validId = "^[a-zA-Z0-9]+$";
		System.out.println("Insurance Id: "+insuranceId);

		if (insuranceId.length()<=0 ) {
	        sessionMap.put("error", "Insurance Id can't be empty !");
	        context.addMessage("form:error", new FacesMessage(FacesMessage.SEVERITY_ERROR, "You must choose at least one search attribute", null));
	        flag = false;
	    }
		
		
//		if (insuranceId.length()!=0 && !insuranceId.matches(validId)) {
//	        sessionMap.put("error", "Insurance Id shouldn't contain any digits or spaces or special charachters !");
//	        context.addMessage("form:error1", new FacesMessage(FacesMessage.SEVERITY_ERROR, "First Name shouldn't contain any digits", null));
//	        flag = false;
//		}

		
		return flag;
	}
    
}