package com.java.manager;

import java.util.List;
import java.util.Map;

import javax.faces.context.FacesContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

public class SubscriptionImpl {
	
	SessionFactory sf;
	Session session;
	
public List<Subscriptions> showSubsciption() {
		
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		Criteria cr = session.createCriteria(Subscriptions.class);
		return cr.list();
	}

public List<Subscriptions> searchInsurance(int firstRow, int rowCount, String insuranceId, String uhId) {
	sf = SessionHelper.getConnection();
    session = sf.openSession();
    Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
   Criteria criteria = session.createCriteria(Subscriptions.class);
 
   criteria.add(Restrictions.eq("uhId", uhId));
   System.out.println("Uhid in IN: "+uhId);
  if(insuranceId.length()>0) {
	  firstRow = 0;
  }
  
   
   if (insuranceId!=null && insuranceId.length() > 0) {
   	
   	System.out.println("Test");
   	
   	criteria.add(Restrictions.ilike("insuranceId", "%" + insuranceId + "%")); 
   	sessionMap.put("insuranceId",insuranceId);
   }
   
        
   // sessionMap.clear();
   
   sessionMap.remove("error");
   criteria.setFirstResult(firstRow);
   criteria.setMaxResults(rowCount);
   System.out.println("First Row: "+firstRow);
   System.out.println("Row Count: "+rowCount);
   List<Subscriptions> insList = criteria.list();
   System.out.println("insList: "+insList);
   return insList;
}

public int countRows2(String insuranceId, String uhId) {
	Map<String, Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
	sf = SessionHelper.getConnection();
	session = sf.openSession();
	try {
		session.beginTransaction();
		Criteria criteria = session.createCriteria(Subscriptions.class);
		if (criteria != null) {
			criteria.add(Restrictions.eq("uhId", uhId));
			System.out.println("Uhid in IN: "+uhId);
			 if (insuranceId!=null && insuranceId.length() > 0) {
			       	
			       	System.out.println("Hi");
			       	
			       	criteria.add(Restrictions.ilike("insuranceId", "%" + insuranceId + "%")); 
			           sessionMap.put("insuranceId",insuranceId );
			       }
			       
			
			        System.out.println("SizeList:"+criteria.list().size());
			return criteria.list().size();
			       
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return 0;
}

public String subscriptionId(int subscriptionId) {	
	// get the sessionMap from the current faces context
	Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
	sf = SessionHelper.getConnection();
	session = sf.openSession();
	
	System.out.println("SearchBeforeUhId: "+subscriptionId);
	
	Criteria cr = session.createCriteria(Subscriptions.class);
	cr.add(Restrictions.eq("subscriptionId", subscriptionId));
	
	System.out.println("SearchAfterUhId: "+subscriptionId);
	
	List<Subscriptions> subList = cr.list();
	
	System.out.println("SubList: "+subList);
	
	//returning the patientList with according to the fetched uhId 
	//this is implemented for the show details
	sessionMap.put("subList", subList);
	
	return "ShowInsuranceDetails.jsp?faces-redirect=true";
	
}
public void reset(Subscriptions sub) {
	sub.setInsuranceId("");
}

}
