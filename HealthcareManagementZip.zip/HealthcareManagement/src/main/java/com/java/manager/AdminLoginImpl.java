package com.java.manager;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpSession;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

public class AdminLoginImpl implements AdminLoginDAO{
	
	SessionFactory sf;
	Session session;
	
	public static int generateOtp() {
		Random r = new Random(System.currentTimeMillis());
		return ((1 + r.nextInt(2)) * 10000 + r.nextInt(10000));
	}

	@Override
	public String adminSignIn(AdminLogin admin) {
		String encr = EncryptPassword.getCode(admin.getPassword());
		Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		SessionFactory sf = SessionHelper.getConnection();
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(AdminLogin.class);
		cr.add(Restrictions.eq("username", admin.getUsername()));
		cr.setProjection(Projections.rowCount());
		long userNameCount = (long) cr.uniqueResult();
		if(userNameCount > 0) {
			return "User Already exit";
		}
		
		admin.setPassword(encr.trim());
		session.beginTransaction();
		int otp = generateOtp();
		admin.setOtp(String.valueOf(otp));
		session.save(admin);
		session.getTransaction().commit();
		String subject = "Welcome to My App";
		String body = "Welcome to Mr/Miss  " + admin.getName() + "\r\n" + "Your OTP Generated Successfully..."
				+ "\r\n" + "OTP is " + otp;
		MailSend.mailSend(admin.getEmail(), "Otp Send Successfully...", body);
		
		return "AdminLogin.jsp?faces-redirect=true";	
	}
	
	@Override
	public String loginDao(AdminLogin adminauth) {
		Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		sf = SessionHelper.getConnection();
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(AdminLogin.class);
		cr.add(Restrictions.eq("username",adminauth.getUsername()));
		cr.add(Restrictions.eq("password",EncryptPassword.getCode(adminauth.getPassword())));
		
		cr.setProjection(Projections.rowCount());
		long count = (long) cr.uniqueResult();
//		if(count == 1) {
//			sessionMap.put("loggedCustomer", adminauth.getUsername());
//			System.out.println(adminauth.getUsername());
//	        sessionMap.put("uhid", adminauth.getId());
//	        System.out.println("uhid from username"+ sessionMap.put("uhid", adminauth.getId()));
//			System.out.println(sessionMap.put("uhid", adminauth.getId()));
//			sf = SessionHelper.getConnection();
//			session = sf.openSession();
//			cr = session.createCriteria(AdminLogin.class);
//			cr.add(Restrictions.eq("username", adminauth.getUsername()));
//			AdminLogin customerFound = (AdminLogin) cr.uniqueResult();
//			sessionMap.put("customerFound", customerFound);
//			sessionMap.put("uhid", customerFound.getId());
//			System.out.println("Sessionfactory");
//			System.out.println(sessionMap.put("uhId", customerFound.getId()));
//			sessionMap.get("loggedCustomer");
//			System.out.println("Logged customer sessionmap");
//			System.out.println(sessionMap.get("loggedCustomer"));
//			return"Dashboard.jsp?faces-redirect=true";
//		}
		if (count == 1) {
		    sessionMap.put("loggedCustomer", adminauth.getUsername());
		    System.out.println("Logged Customer: " + adminauth.getUsername());

		    sessionMap.put("uhid", adminauth.getId());
		    System.out.println("uhid from username: " + adminauth.getId());

		    sf = SessionHelper.getConnection();
		    session = sf.openSession();
		    cr = session.createCriteria(AdminLogin.class);
		    cr.add(Restrictions.eq("username", adminauth.getUsername()));
		    AdminLogin customerFound = (AdminLogin)cr.uniqueResult();

		    if (customerFound != null) {
		        sessionMap.put("customerFound", customerFound);
		        sessionMap.put("uhid", customerFound.getId());
		        System.out.println("uhId from customerFound: " + customerFound.getId());
		        System.out.println("Logged customer sessionmap: " + sessionMap.get("loggedCustomer"));
		        return "Dashboard.jsp?faces-redirect=true";
		    } else {
		        // Handle the case where no customer is found.
		        // You may want to redirect to an error page or do something else.
		        return "AdminLogin.jsp?faces-redirect=true";
		    }
		}
		
		else {
			sessionMap.put("passWordErr3", "Enter a valid UserName and Password.");
			return "AdminLogin.jsp?faces-redirect=true";
		}
	}
	
	  public String logout() {
	        FacesContext facesContext = FacesContext.getCurrentInstance();
	        ExternalContext externalContext = facesContext.getExternalContext();
	        // Invalidate the session
	        HttpSession session = (HttpSession) externalContext.getSession(false);
	        if (session != null) {
	            session.invalidate();
	        }
	        // Clear sessionMap values
	        externalContext.getSessionMap().clear();
	        // Redirect to the login page
	        return "AdminLogin.jsp?faces-redirect=true";
	    }
	
	public String patientId(String id) {	
		// get the sessionMap from the current faces context
		Map<String,Object> sessionMap = FacesContext.getCurrentInstance().getExternalContext().getSessionMap();
		sf = SessionHelper.getConnection();
		session = sf.openSession();
		
		System.out.println("SearchBeforeUhId: "+id);
		
		Criteria cr = session.createCriteria(Patient_Enrollment.class);
		cr.add(Restrictions.eq("id", id));
		
		System.out.println("SearchAfterUhId: "+id);
		
		List<AdminLogin> loginList = cr.list();
		
		System.out.println("PatientList: "+loginList);
		
		//returning the patientList with according to the fetched uhId 
		//this is implemented for the show details
		sessionMap.put("loginList", loginList);
		
		return "DashBoard.jsp?faces-redirect=true";
		
	}

}
