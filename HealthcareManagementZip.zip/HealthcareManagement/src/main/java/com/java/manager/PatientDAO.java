package com.java.manager;

import java.util.List;

public interface PatientDAO {
	
	List<Patient_Enrollment> showPatient();

	List<Patient_Enrollment> searchPatient(int firstRow, int rowCount, String uhId, String firstName, String userName,
			String status);

}
